
//Primero declaro la clase gasto que hereda de la clase dinero
public class Gasto extends Dinero {
	
	// Despues sus metodos
	public Gasto(double gasto, String description) {
        this.dinero = gasto;
        this.description = description;
    }
	
	public String toString() {
        return "Has gastado: " + this.dinero + ". En: " + this.description ;
    }  
}
