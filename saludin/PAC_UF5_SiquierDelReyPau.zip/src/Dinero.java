//Primero declaro la clase dinero
public abstract class Dinero {
	
	//Depu�s sus propiedades
	protected double dinero;
    protected String description;
 
    //Y finalmente sus metodos
    public double getDinero() {
        return dinero;
    }
    
    public void setDinero(double dinero) {
        this.dinero = dinero;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
}
