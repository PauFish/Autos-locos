//Primero declaro la clase ingreso que hereda de la clase dinero
public class Ingreso extends Dinero {
	
	//despues sus metodos
	public Ingreso(double ingreso, String description) {
        this.dinero = ingreso;
        this.description = description;
    }
 
    public String toString() {
        return "Has ingresado: " + this.dinero + ". En concepto de: " + this.description ;
    } 

}
