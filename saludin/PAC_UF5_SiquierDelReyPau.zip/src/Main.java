import java.util.Scanner;

//Primero declaro la clase Main
public class Main {
	
	//Despues todas las propiedades que va a contener
	
	//Propiedades que hacen referencia al usuario
	private static Usuario newUser = new Usuario();
    private static String userName ="";
	
	//Propiedades que hacen referencia a la edad del usuario
    private static String userYears = "";
    private static byte userAge = -1;

	//Propiedades que hacen referencia al dni del usuario
    private static String userDocu = "";
    
    //Propiedades que hacen referencia a la cuenta
    private static boolean accountSet = false;
    private static Cuenta newAccount = null;
    
    //Propiedades que hacen referencia a las opciones del menu
    private static String option = "";
    private static byte chosenOption = -1;
    
    //Propiedades que hacen referencia a gasts e ingresos
    private static String subject = "";
    private static String deposit = "";
    private static double totalDeposit = 0;
    
    //Utilizar� la clase Scanner para que el programa pueda leer los datos que se introducen
  	private static final Scanner reader = new Scanner(System.in);
    
    //despues van los metodos
  	
    //Mostramos las opciones disponibles por consola
    private static void Options(){
        
        do{
        System.out.println("Realiza una nueva accion \n" + "1 Introduce un nuevo gasto \n" + "2 Introduce un nuevo ingreso \n"   
        + "3 Mostrar gastos \n" + "4 Mostrar ingresos \n" + "5 Mostrar saldo \n" + "0 Salir");
        
        try{
            option = reader.nextLine();
            chosenOption = Byte.parseByte(option);
        }
        catch(NumberFormatException e){
            System.out.println(e.getMessage());
            System.out.println("Introduce un valor v�lido");
        }
        }while(chosenOption<0 && chosenOption>5);
    }
    
    //Pedimos los datos del usuario y los guardamos
    
    private static void userDataRequest(){
    	accountSet = false;
    	
        do{
            System.out.println("Introduce tu nombre:");
            userName = reader.nextLine();
            
        }while(userName.isEmpty());
        	newUser.setNombre(userName);     
        do{
            System.out.println("Introduce tu edad");
            userYears = reader.nextLine();
        try{
        	userAge = Byte.parseByte(userYears);
            newUser.setEdad(userAge);
        }catch(NumberFormatException e){
            System.out.println("Introduce un valor valido");
            }
        }while(userYears.isEmpty() || userAge<=0);
        
        
        do{
            System.out.println("Introduce tu dni");
            userDocu = reader.nextLine();
            
        if(newUser.setDNI(userDocu)){
        	newUser.setDNI(userDocu);
        }else{
        	System.out.println("Introduce un valor valido");}
        }while(userDocu.isEmpty() || newUser.setDNI(userDocu) == false);
        accountSet = true;
    	}
    
    //Pedimos los datos de un gasto que se quiera introducir y lo aceptamos si hay saldo suficiente en la cuenta
    private static void withdrawal(){
    	
        deposit = "";
        subject = "";
        totalDeposit = 0;
        
        do{
            System.out.print("Gasto en concepto de: ");
            subject = reader.nextLine();
        }while(subject.isEmpty());
        do{
            System.out.print("El gasto asciende a: ");
            deposit = reader.nextLine();
        try{ 
            totalDeposit = Double.parseDouble(deposit);
        }catch(NumberFormatException e){
            System.out.println("Introduce un valor valido" + e.getMessage());} 
        }while(deposit.isEmpty());
         
        
        if(newAccount.getSaldo()<totalDeposit || newAccount.getSaldo()==0){
            System.out.println("No hay saldo suficiente");}
        else{ 
            newAccount.addGastos(subject, totalDeposit);
            System.out.println("La accion se ha realizado con exito");}
    }
    
    //Metodo para mostrar los gastos que ha tenido el usuario
    private static void showWithdrawal(){
        
       if(!newAccount.getGastos().isEmpty()){
           for(int x=0;x<newAccount.getGastos().size();x++){
               System.out.println(newAccount.getGastos().get(x).toString());
           }
       }
       else{ 
           System.out.println("No hay datos");
       }
    }
    
    //Pedimos los datos de un ingreso que se quiera introducir y lo aceptamos 
    private static void insertDeposit(){
        
        deposit = "";
        subject = "";
        totalDeposit = 0;
        
        do{
            System.out.print("Ingreso en concepto de: ");
            subject = reader.nextLine();
        }while(subject.isEmpty());
        do{
            System.out.print("Importe: ");
            deposit = reader.nextLine();
        try{ 
        	totalDeposit = Double.parseDouble(deposit);
        }catch(NumberFormatException e){
            System.out.println("Introduce un valor valido" + e.getMessage());}
        }while(deposit.isEmpty());
        
        newAccount.addIngresos(subject, totalDeposit);
        System.out.println("La accion se ha realizado con exito");
    }
    
    // Metodo para mostrar los ingresos del usuario
    private static void showDeposit(){
      
       if(!newAccount.getIngresos().isEmpty()){
           for(int x=0;x<newAccount.getIngresos().size();x++){
               System.out.println(newAccount.getIngresos().get(x).toString());
           }
       }
       else{ 
           System.out.println("No hay datos");
       }
    }
    
    public static void main(String[] args) {
        
       //Metodo para crear un usuario
        do{
           userDataRequest();
       }while(accountSet = false);
        
        System.out.println("Usuario:");
        System.out.println(newUser.toString());
        
        //Metodo para crear una cuenta
        newAccount = new Cuenta(newUser);
        
        //Metodos que se van a ejecutar segun el numero que elija el usuario 
        do{Options();
        
        	if (chosenOption == 1) {
        		withdrawal();
        	
        	}else if (chosenOption == 2) {
        		insertDeposit();
        	
        	}else if (chosenOption == 3) {
        		showWithdrawal();
        	
        	}else if (chosenOption == 4) {
        		showDeposit();
        	
        	}else if (chosenOption == 5) {
        		System.out.println(newAccount.toString());
        	
        	}else if (chosenOption == 0) {
        		System.out.println("Fin del programa.\nGracias por utilizar la aplicacion.");
        	
        	}else {
        		System.out.println("Introduce un valor valido");
        }

        }while(chosenOption !=0);
        reader.close();
    }
    
}



