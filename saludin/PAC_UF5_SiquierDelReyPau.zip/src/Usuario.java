//Primero declaro la clase usuario
public class Usuario {

	//Depu�s sus propiedades
	private String nombre;
	private int edad;
	private String DNI;
	
	//Y finalmente sus metodos
    public Usuario() { 
        this.nombre = "";
        this.edad = 0;
        this.DNI = "";
    }
    
    public String getNombre() { 
        return nombre;
    }
    
    public void setNombre(String nombre) { 
        this.nombre = nombre;
    }
    
    public int getEdad() { 
        return edad;
    }
    
    public void setEdad(int edad) { 
        this.edad = edad;
    }
    
    public String getDNI() { 
        return DNI;
    }
    
    //Aqu� compruebo si el dni introducido se corresponde con el esquema 
    public boolean setDNI(String DNI){
        if(DNI.matches("^[0-9]{8}[a-zA-Z]$") || DNI.matches("^[0-9]{8}[-][a-zA-Z]$")){
            this.DNI = DNI;
            return true;
        }
        else{
            return false;
        }      
    }
    
    public String toString() {
        return "Nombre: " + this.nombre + ".\n" +
               "Edad: " + this.edad + ".\n"+
               "DNI: " + this.DNI + ".";
    }

}
