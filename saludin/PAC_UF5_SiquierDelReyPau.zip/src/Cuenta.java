import java.util.*;
//Primero declaro la clase cuenta
public class Cuenta {
	
	//private static final String GastoException = null;
	//Depu�s sus propiedades
	private double saldo; 
    private Usuario usuario; 
    private List<Gasto> gastos; 
    private List<Ingreso> ingresos; 
 
    //Y finalmente sus metodos
    public Cuenta(Usuario usuario) {
        this.usuario = usuario;
        this.saldo = 0;
        this.gastos = new ArrayList<Gasto>();
        this.ingresos = new ArrayList<Ingreso>();
    }
    
    public double getSaldo() {
        return saldo;
    }
    
    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
    
    public Usuario getUsuario() {
        return usuario;
    }
    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }
    
    public double addIngresos(String description, double cantidad){
    	
        //El saldo se incrementa con el ingreso introducido
        Ingreso nuevoIngreso = new Ingreso(cantidad, description);
        this.ingresos.add(nuevoIngreso);
        this.saldo += cantidad;
        return saldo;
    }
    
    //El saldo disminuye con el gasto introducido, siempre y cuando no sea 0 antes de aceptar la transaccion
    //Si no hay saldo, se imprime un mensaje
    public double addGastos(String description, double cantidad){
    		Gasto nuevoGasto = new Gasto(cantidad, description);
    		this.gastos.add(nuevoGasto);
            this.saldo -= cantidad;
            
            if(this.getSaldo()<0){ 	
            System.out.println ("Accion no permitida. Saldo insuficiente.");
            } else {
            return -1;
        }
        return saldo;
    }
    
    public List<Ingreso> getIngresos() {
        return ingresos;
    }
    
    public List<Gasto> getGastos() {
        return gastos;
    }
    
    public String toString(){
        return   "En tu cuenta hay: " + this.saldo;
    }
}
