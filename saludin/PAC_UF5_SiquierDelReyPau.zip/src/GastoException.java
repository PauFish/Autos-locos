////Primero declaro la clase GastoException que hereda de Exception
public class GastoException extends Exception{
	
		//Contiene un solo metodo
		public GastoException(String message) {
		super(message);
	}
	
}
